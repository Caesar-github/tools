v1.28 revision:
1.support to download sparse image and  erase verity info
2.support to erase emmc using erase_lba
